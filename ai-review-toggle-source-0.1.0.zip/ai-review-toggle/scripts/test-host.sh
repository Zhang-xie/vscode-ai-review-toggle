#!/bin/sh
set -eu
# An isolated profile: does not install into or modify your normal VS Code profile.
# Usage: CODE_BIN=/path/to/code ./scripts/test-host.sh /absolute/temp/test-directory
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TEST_ROOT=${1:?Provide an absolute empty test directory}
mkdir -p "$TEST_ROOT/project" "$TEST_ROOT/profile" "$TEST_ROOT/extensions"
export AI_REVIEW_TEST_REPORT="$TEST_ROOT/report.json"
"${CODE_BIN:-code}" --user-data-dir "$TEST_ROOT/profile" --extensions-dir "$TEST_ROOT/extensions" \
  --extensionDevelopmentPath="$ROOT" --extensionTestsPath="$ROOT/test/integration.js" \
  --disable-extensions --disable-workspace-trust --skip-welcome --skip-release-notes \
  "$TEST_ROOT/project"
