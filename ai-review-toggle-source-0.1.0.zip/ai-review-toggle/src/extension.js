'use strict';
const vscode = require('vscode');
const crypto = require('node:crypto');
const { TextDecoder } = require('node:util');
const diff = require('./diff');
const digest = text => crypto.createHash('sha256').update(text === null ? '\0missing' : '\u0001' + text).digest('hex');
const MAX_FILES = 5000;

class Review {
  constructor(context) {
    this.context = context;
    this.session = null;
    this.rows = [];
    this.skipped = 0;
    this.busy = false;
    this.timer = null;
    this.generation = 0;
    this.virtual = new Map();
    this.treeEvent = new vscode.EventEmitter();
    this.lensEvent = new vscode.EventEmitter();
    this.onDidChangeTreeData = this.treeEvent.event;
    this.onDidChangeCodeLenses = this.lensEvent.event;
    this.status = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 90);
    this.status.command = 'aiReview.toggle';
    this.status.name = 'AI Review Toggle';
    this.decoration = vscode.window.createTextEditorDecorationType({
      isWholeLine: true, backgroundColor: new vscode.ThemeColor('diffEditor.insertedTextBackground'),
      overviewRulerColor: new vscode.ThemeColor('editorOverviewRuler.addedForeground'),
      borderWidth: '0 0 0 3px', borderStyle: 'solid', borderColor: new vscode.ThemeColor('gitDecoration.modifiedResourceForeground')
    });
    context.subscriptions.push(this.status, this.decoration, this.treeEvent, this.lensEvent);
    context.subscriptions.push(vscode.window.registerTreeDataProvider('aiReview.changes', this));
    context.subscriptions.push(vscode.languages.registerCodeLensProvider({ scheme: 'file' }, this));
    context.subscriptions.push(vscode.workspace.registerTextDocumentContentProvider('ai-review', {
      provideTextDocumentContent: uri => this.virtual.get(uri.toString()) || ''
    }));
    const command = (name, fn) => context.subscriptions.push(vscode.commands.registerCommand(name, (...args) =>
      this.run(() => fn.apply(this, args))));
    command('aiReview.toggle', this.toggle);
    command('aiReview.refresh', this.refresh);
    command('aiReview.open', () => vscode.commands.executeCommand('aiReview.changes.focus'));
    command('aiReview.viewDiff', this.viewDiff);
    command('aiReview.keepFile', row => this.resolve(row, 'keep'));
    command('aiReview.rejectFile', row => this.resolve(row, 'reject'));
    command('aiReview.keepHunk', (row, index) => this.resolve(row, 'keep', index));
    command('aiReview.rejectHunk', (row, index) => this.resolve(row, 'reject', index));
    command('aiReview.keepAll', this.keepAll);
    const watcher = vscode.workspace.createFileSystemWatcher('**/*');
    context.subscriptions.push(watcher,
      watcher.onDidChange(() => this.schedule()), watcher.onDidCreate(() => this.schedule()), watcher.onDidDelete(() => this.schedule()),
      vscode.workspace.onDidChangeTextDocument(() => this.schedule()),
      vscode.workspace.onDidSaveTextDocument(() => this.schedule()),
      vscode.workspace.onDidCloseTextDocument(doc => { this.virtual.delete(doc.uri.toString()); this.schedule(); }),
      vscode.window.onDidChangeVisibleTextEditors(() => this.decorate()),
      vscode.window.onDidChangeWindowState(state => { if (state.focused) this.schedule(); }),
      { dispose: () => clearTimeout(this.timer) });
    this.paint();
  }
  async run(fn) {
    if (this.busy) { vscode.window.showInformationMessage('AI Review is busy. Try again in a moment.'); return; }
    this.busy = true;
    try { return await fn(); }
    catch (error) { vscode.window.showErrorMessage('AI Review: ' + error.message); }
    finally { this.busy = false; this.schedule(); }
  }
  roots() { return (vscode.workspace.workspaceFolders || []).map(f => f.uri.toString()).sort(); }
  storage() { return vscode.Uri.joinPath(this.context.storageUri, 'session.json'); }
  async persist(session) {
    if (!this.context.storageUri) throw new Error('Open a local project folder first.');
    await vscode.workspace.fs.createDirectory(this.context.storageUri);
    const temp = vscode.Uri.joinPath(this.context.storageUri, 'session.tmp');
    await vscode.workspace.fs.writeFile(temp, Buffer.from(JSON.stringify(session)));
    await vscode.workspace.fs.rename(temp, this.storage(), { overwrite: true });
  }
  async restore() {
    if (!this.context.storageUri) return;
    try {
      const raw = await vscode.workspace.fs.readFile(this.storage());
      const data = JSON.parse(Buffer.from(raw).toString('utf8'));
      if (!data) return;
      if (data.version !== 1 || JSON.stringify(data.roots) !== JSON.stringify(this.roots())) {
        vscode.window.showWarningMessage('AI Review saved session does not match these folders. It was not restored.'); return;
      }
      this.session = data;
      await this.refresh();
      vscode.window.showInformationMessage('AI Review restored your active session. Review is ON.');
    } catch (error) {
      if (error.code !== 'FileNotFound' && error.code !== 'ENOENT') vscode.window.showWarningMessage('AI Review could not restore its snapshot: ' + error.message);
    }
  }
  async read(uri, limit) {
    let stat;
    try { stat = await vscode.workspace.fs.stat(uri); }
    catch (error) { if (error.code === 'FileNotFound' || error.code === 'ENOENT') return null; throw error; }
    if (stat.type !== vscode.FileType.File || stat.size > limit) throw new Error('Unsupported file type or size');
    const open = vscode.workspace.textDocuments.find(d => d.uri.toString() === uri.toString() && !d.isClosed);
    if (open) {
      const text = open.getText();
      if (Buffer.byteLength(text) > limit || text.includes('\0')) throw new Error('Unsupported text size or encoding');
      return text;
    }
    const bytes = await vscode.workspace.fs.readFile(uri);
    if (bytes.length > limit || bytes.includes(0) || (bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf)) throw new Error('Binary, BOM, or oversized file');
    return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  }
  async enumerate(exclude) {
    const uris = await vscode.workspace.findFiles('**/*', exclude, MAX_FILES + 1);
    if (uris.length > MAX_FILES) throw new Error('More than 5,000 candidate files. Narrow AI Review: Exclude or open a smaller folder.');
    return uris.filter(uri => uri.scheme === 'file');
  }
  async toggle() {
    if (this.session) {
      await this.refresh();
      if (this.rows.length || this.skipped) {
        const answer = await vscode.window.showWarningMessage(
          'Turn review off and keep the current files? This clears the snapshot and unresolved review decisions.',
          { modal: true }, 'Keep Everything & Turn Off');
        if (answer !== 'Keep Everything & Turn Off') return;
      }
      await this.persist(null);
      this.session = null; this.rows = []; this.skipped = 0; this.generation++;
      this.paint(); return;
    }
    if (!vscode.workspace.isTrusted) throw new Error('Trust this workspace before starting review.');
    if (!this.roots().length || vscode.workspace.workspaceFolders.some(f => f.uri.scheme !== 'file')) throw new Error('Open a local folder. This version supports local file workspaces only.');
    const config = vscode.workspace.getConfiguration('aiReview');
    const settings = { exclude: config.get('exclude'), limit: config.get('maxFileKB') * 1024, totalLimit: config.get('maxSessionMB') * 1024 * 1024 };
    const next = { version: 1, roots: this.roots(), settings, base: {}, ignored: [], started: new Date().toISOString() };
    this.status.text = '$(sync~spin) AI Review: Starting…';
    try {
      await vscode.window.withProgress({ location: vscode.ProgressLocation.Notification, title: 'AI Review: capturing baseline—wait before starting your agent' }, async progress => {
        const files = await this.enumerate(settings.exclude);
        let total = 0, count = 0;
        for (const uri of files) {
          let text;
          try { text = await this.read(uri, settings.limit); }
          catch { next.ignored.push(uri.toString()); continue; }
          if (text === null) continue;
          total += Buffer.byteLength(text);
          if (total > settings.totalLimit) throw new Error('Snapshot size limit reached. Narrow exclusions or increase AI Review: Max Session MB. Review was not started.');
          next.base[uri.toString()] = text;
          if (++count % 100 === 0) progress.report({ message: `${count} files captured` });
        }
        await this.persist(next);
        this.session = next;
      });
      await this.refresh();
      await vscode.commands.executeCommand('aiReview.changes.focus');
      vscode.window.showInformationMessage(`AI Review is ON. Baseline ready (${Object.keys(next.base).length} text files; ${next.ignored.length} unsupported files skipped). You can start your agent now.`);
    } finally { this.paint(); }
  }
  schedule() {
    if (!this.session) return;
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      if (this.busy) { this.schedule(); return; }
      this.refresh().catch(error => {
        this.status.text = '$(warning) AI Review: refresh failed';
        this.status.tooltip = error.message + '\nUse AI Review: Refresh Changes to retry.';
      });
    }, 350);
  }
  async refresh() {
    if (!this.session) { this.paint(); return; }
    const session = this.session, generation = ++this.generation;
    const files = await this.enumerate(session.settings.exclude);
    const keys = new Set([...Object.keys(session.base), ...files.map(u => u.toString())]);
    const ignored = new Set(session.ignored);
    const rows = [];
    let skipped = ignored.size;
    for (const key of keys) {
      if (ignored.has(key)) continue;
      const uri = vscode.Uri.parse(key);
      let current;
      try { current = await this.read(uri, session.settings.limit); }
      catch { skipped++; continue; }
      const before = Object.hasOwn(session.base, key) ? session.base[key] : null;
      if (before === current) continue;
      rows.push({ key, before, current, beforeHash: digest(before), currentHash: digest(current),
        hunks: before !== null && current !== null ? diff.hunks(before, current) : [], kind: before === null ? 'new' : current === null ? 'deleted' : 'modified' });
    }
    if (this.session !== session || generation !== this.generation) return;
    this.rows = rows.sort((a, b) => a.key.localeCompare(b.key));
    this.skipped = skipped;
    this.paint();
  }
  paint() {
    const active = !!this.session;
    vscode.commands.executeCommand('setContext', 'aiReview.active', active);
    this.status.text = active ? `$(eye) AI Review: ON · ${this.rows.length}${this.skipped ? ' ⚠' : ''}` : '$(eye-closed) AI Review: OFF';
    this.status.backgroundColor = active ? new vscode.ThemeColor('statusBarItem.warningBackground') : undefined;
    this.status.tooltip = active ? `${this.rows.length} files pending; ${this.skipped} unsupported files skipped. Click to turn off. Manual edits are included while ON.` : 'Click before starting an agent to capture a baseline and review changes.';
    this.status.show();
    this.treeEvent.fire(); this.lensEvent.fire(); this.decorate();
  }
  getChildren(element) {
    if (element) return (element.hunks || []).map((h, index) => ({ parent: element, index, h }));
    if (!this.session) return [];
    const items = [...this.rows];
    if (!items.length) items.push({ message: 'No pending changes. Review is ON.' });
    if (this.skipped) items.push({ message: `${this.skipped} unsupported files skipped`, warning: true });
    return items;
  }
  getTreeItem(element) {
    if (element.message) {
      const item = new vscode.TreeItem(element.message);
      item.iconPath = new vscode.ThemeIcon(element.warning ? 'warning' : 'check');
      item.tooltip = element.warning ? 'Binary, oversized, unreadable, or unsupported files cannot be reviewed. Excluded files are not counted.' : element.message;
      return item;
    }
    if (element.parent) {
      const item = new vscode.TreeItem(`Lines ${element.h.b0 + 1}–${Math.max(element.h.b0 + 1, element.h.b1)}`);
      item.command = { command: 'aiReview.viewDiff', title: 'View Change', arguments: [element.parent] };
      item.iconPath = new vscode.ThemeIcon('diff'); return item;
    }
    const item = new vscode.TreeItem(vscode.workspace.asRelativePath(vscode.Uri.parse(element.key)), element.hunks.length ? vscode.TreeItemCollapsibleState.Collapsed : vscode.TreeItemCollapsibleState.None);
    item.description = element.kind + (element.hunks.length ? ` · ${element.hunks.length} blocks` : '');
    item.contextValue = 'reviewFile';
    item.iconPath = new vscode.ThemeIcon(element.kind === 'new' ? 'diff-added' : element.kind === 'deleted' ? 'diff-removed' : 'diff-modified');
    item.tooltip = 'Click for before/after diff. ✓ keeps changes; discard arrow rejects them.';
    item.command = { command: 'aiReview.viewDiff', title: 'Review File', arguments: [element] };
    return item;
  }
  provideCodeLenses(document) {
    if (!this.session) return [];
    const row = this.rows.find(r => r.key === document.uri.toString());
    if (!row || row.current === null || digest(document.getText()) !== row.currentHash) return [];
    const make = (line, title, command, args) => new vscode.CodeLens(new vscode.Range(line, 0, line, 0), { title, command, arguments: args });
    if (row.kind === 'new') return [make(0, '✓ Keep new file', 'aiReview.keepFile', [row]), make(0, '↶ Reject new file', 'aiReview.rejectFile', [row]), make(0, 'View diff', 'aiReview.viewDiff', [row])];
    return row.hunks.flatMap((h, i) => {
      const line = Math.min(h.b0, document.lineCount - 1);
      return [make(line, '✓ Keep change', 'aiReview.keepHunk', [row, i]), make(line, '↶ Reject change', 'aiReview.rejectHunk', [row, i]), make(line, 'View diff', 'aiReview.viewDiff', [row])];
    });
  }
  decorate() {
    for (const editor of vscode.window.visibleTextEditors) {
      const row = this.session && this.rows.find(r => r.key === editor.document.uri.toString());
      const ranges = [];
      if (row && row.current !== null && digest(editor.document.getText()) === row.currentHash) {
        const changes = row.kind === 'new' ? [{ b0: 0, b1: editor.document.lineCount }] : row.hunks;
        for (const h of changes) {
          const start = Math.min(h.b0, editor.document.lineCount - 1), end = Math.min(Math.max(h.b0, h.b1 - 1), editor.document.lineCount - 1);
          ranges.push({ range: new vscode.Range(start, 0, end, editor.document.lineAt(end).text.length), hoverMessage: 'Pending AI Review change. Manual and agent edits are combined. Use Keep / Reject or open the diff.' });
        }
      }
      editor.setDecorations(this.decoration, ranges);
    }
  }
  async viewDiff(row) {
    if (!row || !this.session) return;
    const uri = vscode.Uri.parse(row.key);
    const name = uri.path.split('/').pop();
    const before = vscode.Uri.from({ scheme: 'ai-review', path: '/before/' + name, query: row.beforeHash });
    this.virtual.set(before.toString(), row.before || '');
    let after = uri;
    if (row.current === null) {
      after = vscode.Uri.from({ scheme: 'ai-review', path: '/deleted/' + name, query: row.currentHash });
      this.virtual.set(after.toString(), '');
    }
    await vscode.commands.executeCommand('vscode.diff', before, after, `${name} — AI Review baseline ↔ current`, { preview: true });
  }
  async validate(row) {
    if (!this.session || !row || !row.key) throw new Error('No active review item.');
    const before = Object.hasOwn(this.session.base, row.key) ? this.session.base[row.key] : null;
    const current = await this.read(vscode.Uri.parse(row.key), this.session.settings.limit);
    if (digest(before) !== row.beforeHash || digest(current) !== row.currentHash) {
      await this.refresh(); throw new Error('This file changed since the buttons were shown. Nothing was overwritten. Review the refreshed change and try again.');
    }
    return current;
  }
  async updateBaseline(key, text) {
    const next = { ...this.session, base: { ...this.session.base } };
    if (text === null) delete next.base[key]; else next.base[key] = text;
    const total = Object.values(next.base).reduce((sum, value) => sum + Buffer.byteLength(value), 0);
    if (total > next.settings.totalLimit) throw new Error('Snapshot size limit reached. End this session to keep all changes, then start a smaller session.');
    await this.persist(next);
    this.session = next;
  }
  async resolve(row, action, index) {
    await this.validate(row);
    const h = index === undefined ? null : row.hunks[index];
    if (index !== undefined && !h) throw new Error('This change is no longer available. Refresh the review.');
    if (action === 'keep') {
      await this.updateBaseline(row.key, h ? diff.keep(row.before, row.current, h) : row.current);
    } else {
      const uri = vscode.Uri.parse(row.key);
      if (row.kind === 'new' || row.kind === 'deleted') {
        const label = row.kind === 'new' ? 'Delete New File' : 'Restore Deleted File';
        const answer = await vscode.window.showWarningMessage(`${label}: ${vscode.workspace.asRelativePath(uri)}? Pause your agent before rejecting file changes.`, { modal: true }, label);
        if (answer !== label) return;
        await this.validate(row);
        const open = vscode.workspace.textDocuments.find(d => d.uri.toString() === row.key);
        if (open && open.isDirty) throw new Error('Save or undo unsaved edits before rejecting a file creation or deletion.');
        const edit = new vscode.WorkspaceEdit();
        if (row.kind === 'new') {
          edit.deleteFile(uri, { ignoreIfNotExists: false });
        } else {
          edit.createFile(uri, { overwrite: false, contents: Buffer.from(row.before) });
        }
        if (!await vscode.workspace.applyEdit(edit)) throw new Error('VS Code could not apply the file change.');
      } else {
        const document = await vscode.workspace.openTextDocument(uri);
        // Recheck after openTextDocument: the agent may have edited while it awaited.
        if (digest(document.getText()) !== row.currentHash) throw new Error('The file changed. Refresh and review it again; no edits were overwritten.');
        const next = h ? diff.reject(row.before, row.current, h) : row.before;
        const edit = new vscode.WorkspaceEdit();
        edit.replace(uri, new vscode.Range(document.positionAt(0), document.positionAt(document.getText().length)), next);
        if (!await vscode.workspace.applyEdit(edit)) throw new Error('VS Code rejected the edit because the document changed.');
        // Deliberately leave the editor dirty: never silently save a user's other edits.
        vscode.window.setStatusBarMessage('AI Review: rejected change. Save the file when ready; Undo can restore it.', 5000);
      }
    }
    await this.refresh();
  }
  async keepAll() {
    if (!this.session) return;
    await this.refresh();
    if (!this.rows.length) return;
    const answer = await vscode.window.showInformationMessage(`Keep all changes in ${this.rows.length} files?`, { modal: true }, 'Keep All');
    if (answer !== 'Keep All') return;
    const next = { ...this.session, base: { ...this.session.base } };
    for (const row of this.rows) {
      await this.validate(row);
      if (row.current === null) delete next.base[row.key]; else next.base[row.key] = row.current;
    }
    const total = Object.values(next.base).reduce((sum, value) => sum + Buffer.byteLength(value), 0);
    if (total > next.settings.totalLimit) throw new Error('Snapshot limit reached. Turn review off to keep everything.');
    await this.persist(next); this.session = next;
    await this.refresh();
  }
}
async function activate(context) {
  const review = new Review(context);
  await review.restore();
  return { getReviewState: () => ({ active: !!review.session, changes: JSON.parse(JSON.stringify(review.rows)), skipped: review.skipped }) };
}
module.exports = { activate, Review };
