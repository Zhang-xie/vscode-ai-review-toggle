'use strict';
// Preserve line terminators, including CRLF and missing final newline.
function lines(text) { return text.match(/[^\n]*\n|[^\n]+$/g) || []; }
function hunks(before, after) {
  const a = lines(before), b = lines(after);
  let prefix = 0;
  while (prefix < a.length && prefix < b.length && a[prefix] === b[prefix]) prefix++;
  let ae = a.length, be = b.length;
  while (ae > prefix && be > prefix && a[ae - 1] === b[be - 1]) { ae--; be--; }
  if (prefix === ae && prefix === be) return [];
  const n = ae - prefix, m = be - prefix;
  // Bounded LCS: very broad rewrites become one review block, not a UI freeze.
  if ((n + 1) * (m + 1) > 1000000) return [{ a0: prefix, a1: ae, b0: prefix, b1: be }];
  const width = m + 1, dp = new Uint32Array((n + 1) * width);
  for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) {
    dp[i * width + j] = a[prefix + i] === b[prefix + j]
      ? 1 + dp[(i + 1) * width + j + 1]
      : Math.max(dp[(i + 1) * width + j], dp[i * width + j + 1]);
  }
  let i = 0, j = 0, h = null;
  const result = [];
  const flush = () => { if (h) { h.a1 = prefix + i; h.b1 = prefix + j; result.push(h); h = null; } };
  while (i < n || j < m) {
    if (i < n && j < m && a[prefix + i] === b[prefix + j]) { flush(); i++; j++; }
    else {
      if (!h) h = { a0: prefix + i, b0: prefix + j };
      if (i < n && (j === m || dp[(i + 1) * width + j] >= dp[i * width + j + 1])) i++;
      else j++;
    }
  }
  flush();
  return result;
}
function keep(before, after, h) {
  const a = lines(before), b = lines(after);
  return [...a.slice(0, h.a0), ...b.slice(h.b0, h.b1), ...a.slice(h.a1)].join('');
}
function reject(before, after, h) {
  const a = lines(before), b = lines(after);
  return [...b.slice(0, h.b0), ...a.slice(h.a0, h.a1), ...b.slice(h.b1)].join('');
}
module.exports = { lines, hunks, keep, reject };
