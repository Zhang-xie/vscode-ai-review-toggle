# Validation — version 0.1.0

Build date: 2026-11-17.

## Completed

- JavaScript syntax validation using VS Code's bundled Node.js 24.21.0.
- **30 automated tests passed**: 13 diff tests and 17 simulated VS Code control tests.
- The diff tests include 1,000 deterministic randomized before/after round trips,
  Unicode, CRLF, missing final newlines, empty files, independent blocks, and a
  large rewrite exercising the bounded-computation fallback.
- Control tests cover pre-existing unsaved work, partial Keep/Reject, stale
  actions, storage failure, dirty buffers, new-file deletion, deleted-file
  restoration, persistence/reload, skipped files, turning review off, snapshot
  limits, Keep All, and an edit arriving while the document is being opened.
- The standard VSIX package was accepted by the installed VS Code CLI using
  **temporary profile and extension directories under `work/`**.
- The CLI listed `local-review-tools.ai-review-toggle@0.1.0` in that isolated
  extension directory.
- Package archive integrity and XML/JSON manifests were checked. Runtime files
  inside the package were compared byte-for-byte with the delivered source.

The user's normal VS Code extension directory, settings, and profile were not
changed. No Marketplace upload was performed.

## Not completed

The real GUI Extension Development Host failed to launch in this execution
environment (the direct GUI process exited with code 134). Consequently,
**visual rendering and actual editor integration are not yet end-to-end
verified**. The simulated tests are not a substitute for that verification.
The real-host test is provided in `test/integration.js` with an isolated launch
script at `scripts/test-host.sh`.

Windows and Linux were not tested. The implementation uses portable VS Code APIs,
but platform behavior should be checked before a general public release.

## First editor smoke check

1. Install the VSIX and open a small disposable folder.
2. Create a file containing five lines and save it.
3. Turn AI Review ON and wait for the baseline-ready notification.
4. Change line one and line five. Verify that two sets of Keep/Reject controls appear.
5. Keep the first change, reject the second, and save. Verify only line one remains changed.
6. Make another edit, reload the window, and verify the session restores.
7. Turn review OFF and choose Keep Everything & Turn Off. Ordinary edits should show no review controls.

Pause external writers before using Reject. A snapshot observer cannot lock
another process out of the file system, even with stale-action checks.
