'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { hunks, keep, reject } = require('../src/diff');
const cases = [
  ['', ''], ['', 'hello'], ['hello', ''], ['a\nb\nc\n', 'a\nB\nc\n'],
  ['a\nb\nc\nd\ne\n', 'A\nb\nc\nd\nE\n'],
  ['a\r\nb\r\n', 'a\r\nB\r\n'], ['a\n', 'a'], ['a', 'a\n'],
  ['😀\n汉字\n', '😀\n中文\n'], ['a\na\nb\n', 'a\nb\na\n']
];
for (const [before, after] of cases) test(`round trip ${JSON.stringify(before)} -> ${JSON.stringify(after)}`, () => {
  let baseline = before;
  for (let guard = 0; baseline !== after && guard < 100; guard++) baseline = keep(baseline, after, hunks(baseline, after)[0]);
  assert.equal(baseline, after);
  let current = after;
  for (let guard = 0; current !== before && guard < 100; guard++) current = reject(before, current, hunks(before, current)[0]);
  assert.equal(current, before);
});
test('accept and reject independent blocks preserve the other block', () => {
  const a = 'one\ntwo\nthree\nfour\nfive\n', b = 'ONE\ntwo\nthree\nfour\nFIVE\n';
  const hs = hunks(a, b);
  assert.equal(hs.length, 2);
  assert.equal(keep(a, b, hs[0]), 'ONE\ntwo\nthree\nfour\nfive\n');
  assert.equal(reject(a, b, hs[1]), 'ONE\ntwo\nthree\nfour\nfive\n');
});
test('broad rewrites have bounded computation and remain reversible', () => {
  const a = Array.from({length: 2000}, (_, i) => `old ${i}\n`).join('');
  const b = Array.from({length: 2000}, (_, i) => `new ${i}\n`).join('');
  const hs = hunks(a, b);
  assert.equal(hs.length, 1); assert.equal(reject(a, b, hs[0]), a); assert.equal(keep(a, b, hs[0]), b);
});
test('1,000 deterministic random edit round trips', () => {
  let seed = 42;
  const random = n => { seed = (1664525 * seed + 1013904223) >>> 0; return seed % n; };
  for (let t = 0; t < 1000; t++) {
    const make = () => Array.from({length: random(16)}, () => ['a\n', 'b\n', 'c\n', '\n', '🐈\r\n'][random(5)]).join('');
    const a = make(), b = make();
    let x = a, y = b;
    for (let i = 0; x !== b && i < 100; i++) x = keep(x, b, hunks(x, b)[0]);
    for (let i = 0; y !== a && i < 100; i++) y = reject(a, y, hunks(a, y)[0]);
    assert.equal(x, b); assert.equal(y, a);
  }
});
