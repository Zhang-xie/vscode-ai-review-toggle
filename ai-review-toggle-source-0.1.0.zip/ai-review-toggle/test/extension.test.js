'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');

function setup() {
  const files = new Map(), docs = new Map(), errors = [], answers = [], commands = new Map();
  const emitted = [], subscriptions = [];
  const missing = () => Object.assign(new Error('Missing'), { code: 'FileNotFound' });
  class Uri {
    constructor(value) { this.value = value; const u = new URL(value); this.scheme = u.protocol.slice(0, -1); this.path = u.pathname; }
    toString() { return this.value; }
    static parse(v) { return new Uri(v); }
    static joinPath(uri, ...parts) { return new Uri(uri.toString().replace(/\/$/, '') + '/' + parts.join('/')); }
    static from({ scheme, path: p, query }) { return new Uri(`${scheme}://${p}?${query || ''}`); }
  }
  class EventEmitter {
    constructor() { this.handlers = []; this.event = callback => { this.handlers.push(callback); return { dispose() {} }; }; }
    fire(value) { for (const callback of this.handlers) callback(value); }
    dispose() {}
  }
  class Position { constructor(line, character) { this.line = line; this.character = character; } }
  class Range { constructor(a, b, c, d) { this.start = typeof a === 'number' ? new Position(a, b) : a; this.end = typeof a === 'number' ? new Position(c, d) : b; } }
  class WorkspaceEdit {
    constructor() { this.edits = []; }
    replace(uri, range, text) { this.edits.push({ type: 'replace', uri, range, text, version: docs.get(uri.toString())?.version }); }
    createFile(uri, options) { this.edits.push({ type: 'create', uri, options }); }
    deleteFile(uri, options) { this.edits.push({ type: 'delete', uri, options }); }
  }
  const noopEvent = () => ({ dispose() {} });
  let failure = false;
  const config = { exclude: '**/node_modules/**', maxFileKB: 256, maxSessionMB: 32 };
  const storage = {
    async createDirectory() {},
    async stat(uri) { const b = files.get(uri.toString()); if (!b) throw missing(); return { type: 1, size: b.length }; },
    async readFile(uri) { const b = files.get(uri.toString()); if (!b) throw missing(); return b; },
    async writeFile(uri, data) { if (failure) throw new Error('Disk full'); files.set(uri.toString(), Buffer.from(data)); },
    async rename(a, b) { if (failure) throw new Error('Disk full'); files.set(b.toString(), files.get(a.toString())); files.delete(a.toString()); }
  };
  function document(uri) {
    const key = uri.toString();
    if (docs.has(key)) return docs.get(key);
    if (!files.has(key)) throw missing();
    const doc = { uri, text: files.get(key).toString(), isDirty: false, version: 1, isClosed: false,
      getText() { return this.text; },
      get lineCount() { return this.text.split('\n').length; },
      positionAt(offset) { const parts = this.text.slice(0, offset).split('\n'); return new Position(parts.length - 1, parts.at(-1).length); },
      lineAt(line) { return { text: this.text.split('\n')[line] || '' }; }
    };
    docs.set(key, doc); return doc;
  }
  const vscode = {
    Uri, EventEmitter, Range, WorkspaceEdit,
    ThemeColor: class { constructor(id) { this.id = id; } }, ThemeIcon: class {},
    CodeLens: class { constructor(range, command) { this.range = range; this.command = command; } },
    TreeItem: class { constructor(label) { this.label = label; } },
    TreeItemCollapsibleState: { None: 0, Collapsed: 1 }, StatusBarAlignment: { Left: 1 }, ProgressLocation: { Notification: 1 }, FileType: { File: 1 },
    commands: {
      registerCommand(id, fn) { commands.set(id, fn); return { dispose() {} }; },
      async executeCommand(id, ...args) { return commands.get(id)?.(...args); }
    },
    languages: { registerCodeLensProvider() { return { dispose() {} }; } },
    window: {
      visibleTextEditors: [],
      createStatusBarItem() { return { show() {}, dispose() {} }; },
      createTextEditorDecorationType() { return { dispose() {} }; },
      registerTreeDataProvider() { return { dispose() {} }; },
      showInformationMessage: async () => answers.shift(),
      showWarningMessage: async () => answers.shift(),
      showErrorMessage: text => { errors.push(text); },
      withProgress: async (_, fn) => fn({ report() {} }),
      setStatusBarMessage() {}, onDidChangeVisibleTextEditors: noopEvent, onDidChangeWindowState: noopEvent
    },
    workspace: {
      fs: storage, isTrusted: true, workspaceFolders: [{ uri: Uri.parse('file:///project') }],
      get textDocuments() { return [...docs.values()]; },
      getConfiguration: () => ({ get: name => config[name] }),
      findFiles: async () => [...files.keys()].filter(k => k.startsWith('file:///project/') && !k.includes('/node_modules/')).map(Uri.parse),
      asRelativePath: uri => uri.path.replace('/project/', ''),
      openTextDocument: async uri => document(uri),
      registerTextDocumentContentProvider() { return { dispose() {} }; },
      createFileSystemWatcher: () => ({ onDidChange: noopEvent, onDidCreate: noopEvent, onDidDelete: noopEvent, dispose() {} }),
      onDidChangeTextDocument: noopEvent, onDidSaveTextDocument: noopEvent, onDidCloseTextDocument: noopEvent,
      async applyEdit(edit) {
        for (const item of edit.edits) {
          const key = item.uri.toString();
          if (item.type === 'replace' && docs.get(key)?.version !== item.version) return false;
          if (item.type === 'create' && files.has(key) && !item.options.overwrite) return false;
        }
        for (const item of edit.edits) {
          const key = item.uri.toString();
          if (item.type === 'replace') { const d = document(item.uri); d.text = item.text; d.version++; d.isDirty = true; }
          if (item.type === 'create') files.set(key, Buffer.from(item.options.contents || ''));
          if (item.type === 'delete') { files.delete(key); docs.delete(key); }
        }
        emitted.push(edit); return true;
      }
    }
  };
  const module = { exports: {} };
  const source = fs.readFileSync(path.join(__dirname, '../src/extension.js'), 'utf8');
  const requireMock = id => id === 'vscode' ? vscode : id === './diff' ? require('../src/diff') : require(id);
  vm.runInNewContext(source, { require: requireMock, module, Buffer, setTimeout, clearTimeout, console }, { filename: 'extension.js' });
  const context = { subscriptions, storageUri: Uri.parse('file:///storage') };
  const review = new module.exports.Review(context);
  return { review, vscode, files, docs, errors, answers, config, emitted, context,
    write(name, text) { const key = 'file:///project/' + name; files.set(key, Buffer.from(text)); if (docs.has(key)) { docs.get(key).text = text; docs.get(key).version++; } return Uri.parse(key); },
    edit(name, text) { const d = document(Uri.parse('file:///project/' + name)); d.text = text; d.version++; d.isDirty = true; return d; },
    failStorage() { failure = true; },
    cleanup() { for (const sub of subscriptions) sub.dispose(); },
    another() { return new module.exports.Review(context); }
  };
}
async function withReview(fn) { const env = setup(); try { await fn(env); } finally { env.cleanup(); } }
const start = async env => { env.write('a.txt', 'one\ntwo\nthree\nfour\nfive\n'); await env.review.toggle(); };

test('baseline captures existing unsaved work; OFF mode has no lenses', () => withReview(async e => {
  e.write('a.txt', 'disk\n'); const doc = e.edit('a.txt', 'unsaved baseline\n');
  assert.equal(e.review.provideCodeLenses(doc).length, 0);
  await e.review.toggle(); assert.equal(e.review.session.base[doc.uri.toString()], 'unsaved baseline\n');
  assert.equal(e.review.rows.length, 0);
}));
test('keep first block and reject second preserves accepted change', () => withReview(async e => {
  await start(e); const doc = e.edit('a.txt', 'ONE\ntwo\nthree\nfour\nFIVE\n');
  await e.review.refresh(); assert.equal(e.review.rows[0].hunks.length, 2);
  assert.equal(e.review.provideCodeLenses(doc).length, 6);
  await e.review.resolve(e.review.rows[0], 'keep', 0);
  assert.equal(e.review.rows[0].hunks.length, 1);
  await e.review.resolve(e.review.rows[0], 'reject', 0);
  assert.equal(doc.text, 'ONE\ntwo\nthree\nfour\nfive\n'); assert.equal(doc.isDirty, true);
  assert.equal(e.review.rows.length, 0);
}));
test('stale reject refuses to overwrite a new manual edit', () => withReview(async e => {
  await start(e); e.edit('a.txt', 'agent\n'); await e.review.refresh(); const row = e.review.rows[0];
  const doc = e.edit('a.txt', 'newer manual edit\n');
  await assert.rejects(e.review.resolve(row, 'reject', 0), /changed since/);
  assert.equal(doc.text, 'newer manual edit\n'); assert.equal(e.emitted.length, 0);
}));
test('stale keep cannot approve unseen edits', () => withReview(async e => {
  await start(e); e.edit('a.txt', 'agent\n'); await e.review.refresh(); const row = e.review.rows[0];
  e.edit('a.txt', 'newer edit\n'); await assert.rejects(e.review.resolve(row, 'keep'), /changed since/);
  assert.equal(e.review.session.base[row.key], 'one\ntwo\nthree\nfour\nfive\n');
}));
test('persistence failure leaves the previous baseline intact', () => withReview(async e => {
  await start(e); e.edit('a.txt', 'agent\n'); await e.review.refresh(); const row = e.review.rows[0];
  e.failStorage(); await assert.rejects(e.review.resolve(row, 'keep'), /Disk full/);
  assert.equal(e.review.session.base[row.key], row.before);
}));
test('new-file rejection requires consent and refuses dirty buffers', () => withReview(async e => {
  await start(e); e.write('new.txt', 'new\n'); const doc = e.edit('new.txt', 'unsaved\n'); await e.review.refresh();
  const row = e.review.rows.find(r => r.kind === 'new'); e.answers.push('Delete New File');
  await assert.rejects(e.review.resolve(row, 'reject'), /unsaved edits/);
  assert.equal(doc.text, 'unsaved\n'); assert.ok(e.files.has(row.key));
}));
test('new file reject deletes only after confirmation', () => withReview(async e => {
  await start(e); const uri = e.write('new.txt', 'new\n'); await e.review.refresh();
  const row = e.review.rows.find(r => r.kind === 'new');
  await e.review.resolve(row, 'reject'); assert.ok(e.files.has(uri.toString()));
  e.answers.push('Delete New File'); await e.review.resolve(row, 'reject'); assert.equal(e.files.has(uri.toString()), false);
}));
test('deleted file can be restored with its original bytes', () => withReview(async e => {
  await start(e); e.files.delete('file:///project/a.txt'); await e.review.refresh();
  const row = e.review.rows[0]; assert.equal(row.kind, 'deleted');
  e.answers.push('Restore Deleted File'); await e.review.resolve(row, 'reject');
  assert.equal(e.files.get(row.key).toString(), row.before); assert.equal(e.review.rows.length, 0);
}));
test('deleted file restored by another process is not overwritten', () => withReview(async e => {
  await start(e); e.files.delete('file:///project/a.txt'); await e.review.refresh(); const row = e.review.rows[0];
  e.write('a.txt', 'someone restored this\n');
  await assert.rejects(e.review.resolve(row, 'reject'), /changed since/);
  assert.equal(e.files.get(row.key).toString(), 'someone restored this\n');
}));
test('active session restores baseline after reload', () => withReview(async e => {
  await start(e); e.write('a.txt', 'changed on disk\n');
  const restarted = e.another(); await restarted.restore();
  assert.ok(restarted.session); assert.equal(restarted.rows.length, 1);
  assert.equal(restarted.rows[0].before, 'one\ntwo\nthree\nfour\nfive\n');
}));
test('binary and oversized files are visibly excluded', () => withReview(async e => {
  e.write('binary.dat', Buffer.from([0, 1, 2])); e.write('big.txt', 'x'.repeat(300000));
  await start(e); assert.equal(e.review.skipped, 2); assert.equal(Object.keys(e.review.session.base).length, 1);
}));
test('turning OFF can be cancelled; confirmation keeps files and clears snapshot', () => withReview(async e => {
  await start(e); e.write('a.txt', 'agent\n'); await e.review.refresh();
  await e.review.toggle(); assert.ok(e.review.session);
  e.answers.push('Keep Everything & Turn Off'); await e.review.toggle();
  assert.equal(e.review.session, null); assert.equal(e.files.get('file:///project/a.txt').toString(), 'agent\n');
  assert.equal(e.files.get('file:///storage/session.json').toString(), 'null');
}));
test('empty review can turn OFF without a prompt', () => withReview(async e => {
  await start(e); await e.review.toggle(); assert.equal(e.review.session, null);
}));
test('snapshot size cap fails closed instead of partially starting', () => withReview(async e => {
  e.config.maxSessionMB = 0.000001;
  await assert.rejects(start(e), /Snapshot size limit/); assert.equal(e.review.session, null);
}));
test('Keep All resolves multiple files without rewriting them', () => withReview(async e => {
  await start(e); e.write('a.txt', 'changed\n'); e.write('new.txt', 'added\n'); await e.review.refresh();
  e.answers.push('Keep All'); await e.review.keepAll();
  assert.equal(e.review.rows.length, 0); assert.equal(e.emitted.length, 0);
  assert.equal(e.review.session.base['file:///project/new.txt'], 'added\n');
}));
test('restoring deleted file refuses to overwrite a dirty open buffer', () => withReview(async e => {
  await start(e); const doc = e.edit('a.txt', 'unsaved work\n');
  e.files.delete('file:///project/a.txt'); await e.review.refresh();
  e.answers.push('Restore Deleted File');
  await assert.rejects(e.review.resolve(e.review.rows[0], 'reject'), /unsaved edits/);
  assert.equal(doc.text, 'unsaved work\n'); assert.equal(e.emitted.length, 0);
}));
test('change arriving while opening a document is refused', () => withReview(async e => {
  await start(e); e.write('a.txt', 'agent\n'); await e.review.refresh(); const row = e.review.rows[0];
  const originalOpen = e.vscode.workspace.openTextDocument;
  e.vscode.workspace.openTextDocument = async uri => { const doc = await originalOpen(uri); doc.text = 'concurrent edit\n'; doc.version++; return doc; };
  await assert.rejects(e.review.resolve(row, 'reject'), /file changed/);
  assert.equal(e.docs.get(row.key).text, 'concurrent edit\n'); assert.equal(e.emitted.length, 0);
}));
