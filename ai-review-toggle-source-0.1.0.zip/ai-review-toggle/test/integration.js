'use strict';
// Run in an isolated VS Code Extension Development Host. See scripts/test-host.sh.
const vscode = require('vscode');
const assert = require('node:assert/strict');
const fs = require('node:fs');
async function run() {
  const folder = vscode.workspace.workspaceFolders[0].uri;
  const uri = vscode.Uri.joinPath(folder, 'sample.txt');
  const binary = vscode.Uri.joinPath(folder, 'binary.bin');
  const original = 'one\ntwo\nthree\nfour\nfive\n';
  await vscode.workspace.fs.writeFile(uri, Buffer.from(original));
  await vscode.workspace.fs.writeFile(binary, new Uint8Array([0, 255, 0]));
  const extension = vscode.extensions.getExtension('local-review-tools.ai-review-toggle');
  const api = await extension.activate();
  const cmd = (name, ...args) => vscode.commands.executeCommand('aiReview.' + name, ...args);
  const state = () => api.getReviewState();
  const document = await vscode.workspace.openTextDocument(uri);
  const replace = async text => {
    const e = new vscode.WorkspaceEdit();
    e.replace(uri, new vscode.Range(document.positionAt(0), document.positionAt(document.getText().length)), text);
    assert.equal(await vscode.workspace.applyEdit(e), true);
    await cmd('refresh');
  };
  // Unsaved text at session start is the baseline.
  await replace('manual baseline\n' + original);
  const baseline = document.getText();
  await cmd('toggle');
  assert.equal(state().active, true);
  assert.equal(state().skipped, 1);
  assert.equal(state().changes.length, 0);
  await replace(baseline.replace('one\n', 'ONE\n').replace('five\n', 'FIVE\n'));
  assert.equal(state().changes.length, 1);
  assert.equal(state().changes[0].hunks.length, 2);
  let row = state().changes[0];
  const lenses = await vscode.commands.executeCommand('vscode.executeCodeLensProvider', uri);
  assert.ok(lenses.some(lens => lens.command && lens.command.command === 'aiReview.keepHunk'));
  await cmd('keepHunk', row, 0);
  assert.equal(state().changes[0].hunks.length, 1);
  row = state().changes[0];
  await cmd('rejectHunk', row, 0);
  assert.equal(document.getText(), baseline.replace('one\n', 'ONE\n'));
  assert.equal(state().changes.length, 0);
  assert.equal(document.isDirty, true);
  // Stale actions must not erase a newer edit.
  await replace(document.getText().replace('three\n', 'THREE\n'));
  row = state().changes[0];
  await replace(document.getText() + 'new manual edit\n');
  const latest = document.getText();
  await cmd('rejectHunk', row, 0);
  assert.equal(document.getText(), latest);
  await cmd('keepFile', state().changes[0]);
  // New files have an explicit file-level decision.
  const newUri = vscode.Uri.joinPath(folder, 'new.txt');
  await vscode.workspace.fs.writeFile(newUri, Buffer.from('new file\n'));
  await cmd('refresh');
  assert.equal(state().changes.find(r => r.key === newUri.toString()).kind, 'new');
  await cmd('keepFile', state().changes.find(r => r.key === newUri.toString()));
  // Deletions are detected, even though no editor can be opened.
  await vscode.workspace.fs.delete(newUri);
  await cmd('refresh');
  assert.equal(state().changes.find(r => r.key === newUri.toString()).kind, 'deleted');
  await cmd('keepFile', state().changes.find(r => r.key === newUri.toString()));
  // Skip warning remains; disabling uses a modal, so leave the isolated host ON.
  assert.equal(state().changes.length, 0);
  const report = { passed: true, checks: ['activation', 'baseline includes unsaved edits', 'binary exclusion', 'two separate hunks', 'CodeLens actions', 'partial keep', 'partial reject', 'unsaved undoable result', 'stale action protection', 'new files', 'deleted files', 'keep file'] };
  fs.writeFileSync(process.env.AI_REVIEW_TEST_REPORT, JSON.stringify(report, null, 2));
}
module.exports = { run };
