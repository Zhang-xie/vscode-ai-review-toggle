# Changelog

## 0.1.0 — 2026-11-17

Initial preview release: workspace review toggle, baseline snapshots, per-block
Keep / Reject, before/after diffs, file creation/deletion review, session recovery,
stale-action checks, configurable exclusions, bounded diff calculation, and
local-only storage. No runtime dependencies or model credentials.
